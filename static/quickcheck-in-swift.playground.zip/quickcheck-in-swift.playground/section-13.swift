extension String : Arbitrary {
    static func arbitrary() -> String {
      return randomString()
    }
}

extension Int : Arbitrary {
    static func arbitrary() -> Int {
        return random(from: 0, to: 10000)
    }
}