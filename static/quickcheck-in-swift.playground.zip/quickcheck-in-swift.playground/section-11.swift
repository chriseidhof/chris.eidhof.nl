protocol Arbitrary {
    class func arbitrary() -> Self
}