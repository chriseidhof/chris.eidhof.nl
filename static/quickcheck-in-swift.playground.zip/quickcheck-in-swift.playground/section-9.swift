func prop_doubleReverse(x : String) -> Bool {
    return x.reverse().reverse() == x
}

func random (#from: Int, #to: Int) -> Int {
    return from + (Int(arc4random()) % to)
}

func randomString() -> String {
  let randomLength = random(from: 0, to: numberOfIterations)
  var string = ""
  for i in 0..randomLength {
      let randomInt : Int = random(from: 13, to: 255)
      string += Character(UnicodeScalar(randomInt))
  }
  return string
}

for _ in 0..numberOfIterations {
    assert(prop_doubleReverse(randomString()))
}