func check<X : Arbitrary, Y: Arbitrary>(prop: (X,Y) -> Bool) -> () {
    for _ in 0..numberOfIterations {
        let valX = X.arbitrary()
        let valY = Y.arbitrary()
        assert(prop(valX,valY))
    }
}