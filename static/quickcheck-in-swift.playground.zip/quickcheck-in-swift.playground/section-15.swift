func check<X : Arbitrary>(prop : X -> Bool) -> () {
    for _ in 0..numberOfIterations {
        let val = X.arbitrary()
        assert(prop(val))
    }
}
