let numberOfIterations = 100 

for _ in 0..numberOfIterations {
    let valX = Int(arc4random())
    let valY = Int(arc4random())
    assert(prop_plusCommutative(valX,valY))
}