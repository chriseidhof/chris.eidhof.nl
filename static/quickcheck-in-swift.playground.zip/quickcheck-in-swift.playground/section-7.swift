extension String {
    func reverse() -> String {
        var s = ""
        for char in self {
            s = char + s
        }
        return s
    }
}